import { WORLD } from "./config.js";

const NS = "http://www.w3.org/2000/svg";
const el = (name, attrs={}) => {
  const node = document.createElementNS(NS, name);
  for (const [k,v] of Object.entries(attrs)) node.setAttribute(k, v);
  return node;
};
const pathData = pts => pts.map((p,i)=>`${i?"L":"M"} ${p[0]} ${p[1]}`).join(" ");

export function renderScene(scene) {
  const base = document.querySelector("#baseLayer");
  const roads = document.querySelector("#roadLayer");
  const districts = document.querySelector("#districtLayer");
  const labels = document.querySelector("#labelLayer");
  const objects = document.querySelector("#screenObjects");

  base.replaceChildren(el("rect",{x:0,y:0,width:WORLD.width,height:WORLD.height,class:"scene-bg"}));
  districts.replaceChildren();
  roads.replaceChildren();
  labels.replaceChildren();
  objects.replaceChildren();

  for (const d of scene.districts || []) {
    districts.append(el("polygon",{points:d.points.map(p=>p.join(",")).join(" "),class:"district-shape","data-id":d.id}));
    const t=el("text",{x:d.label.x,y:d.label.y,class:"scene-label","text-anchor":"middle"});
    t.textContent=d.name; labels.append(t);
  }
  for (const r of scene.roads || []) {
    roads.append(el("path",{d:pathData(r.points),class:r.kind==="major"?"road":"road-minor"}));
    if(r.kind==="major") roads.append(el("path",{d:pathData(r.points),class:"road-mark"}));
  }
  for (const obj of scene.objects || []) {
    const node=document.createElement("button");
    node.className=`map-object ${obj.type}`;
    node.style.left=`${obj.x}px`; node.style.top=`${obj.y}px`;
    node.dataset.objectId=obj.id; node.type="button";
    const pin=document.createElement("span"); pin.className="pin";
    pin.textContent=iconFor(obj.icon);
    const name=document.createElement("span"); name.className="name"; name.textContent=obj.name;
    node.append(pin,name); objects.append(node);
  }
}
function iconFor(key){return ({coffee:"☕",restaurant:"🍔",billboard:"▣",event:"✦",shop:"▤"})[key]||"●";}
