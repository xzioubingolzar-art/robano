// دوربین صحنه: مختصات جهان -> مختصات صفحه با scale و translate
export function createCamera(worldEl, viewport) {
  let x=0,y=0,scale=.48;
  const min=.28,max=2.2;
  function apply(){worldEl.style.transform=`translate(${x}px,${y}px) scale(${scale})`;}
  function zoom(factor,cx=viewport.clientWidth/2,cy=viewport.clientHeight/2){
    const beforeX=(cx-x)/scale, beforeY=(cy-y)/scale;
    scale=Math.max(min,Math.min(max,scale*factor));
    x=cx-beforeX*scale; y=cy-beforeY*scale; apply();
  }
  function reset(){scale=.48;x=(viewport.clientWidth-2000*scale)/2;y=(viewport.clientHeight-1400*scale)/2;apply();}
  function pan(dx,dy){x+=dx;y+=dy;apply();}
  function get(){return {x,y,scale};}
  apply(); return {zoom,reset,pan,get,apply};
}
