// ابعاد صحنه در واحدهای منطقی؛ مستقل از اندازه نمایشگر
export const WORLD = { width: 2000, height: 1400 };
export const INITIAL_VIEW = { x: 0, y: 0, scale: 0.48 };
export const LAYER_ORDER = ["base", "roads", "districts", "businesses", "billboards", "events", "labels"];
