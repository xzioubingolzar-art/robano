import { renderScene } from "./scene-renderer.js";
import { createCamera } from "./camera.js";

const response = await fetch("./data/scene.json");
const scene = await response.json();
renderScene(scene);

const viewport=document.querySelector("#sceneViewport");
const world=document.querySelector("#world");
const camera=createCamera(world,viewport);
camera.reset();
document.querySelector("#zoomIn").addEventListener("click",()=>camera.zoom(1.2));
document.querySelector("#zoomOut").addEventListener("click",()=>camera.zoom(1/1.2));
document.querySelector("#resetView").addEventListener("click",()=>camera.reset());

let drag=null;
viewport.addEventListener("pointerdown",e=>{if(e.target.closest(".map-object"))return;drag={x:e.clientX,y:e.clientY};viewport.setPointerCapture(e.pointerId);});
viewport.addEventListener("pointermove",e=>{if(!drag)return;camera.pan(e.clientX-drag.x,e.clientY-drag.y);drag={x:e.clientX,y:e.clientY};});
viewport.addEventListener("pointerup",()=>drag=null);
viewport.addEventListener("pointercancel",()=>drag=null);

const feed=document.querySelector("#feed");
function showObject(obj){
  document.querySelector("#panelTitle").textContent=obj.name;
  document.querySelector("#panelSubtitle").textContent=obj.description;
}
document.querySelector("#screenObjects").addEventListener("click",e=>{
  const button=e.target.closest("[data-object-id]"); if(!button)return;
  const obj=scene.objects.find(o=>o.id===button.dataset.objectId); if(obj)showObject(obj);
});
for(const obj of scene.objects){
  const card=document.createElement("article"); card.className="feed-card";
  const title=document.createElement("b");title.textContent=obj.name;
  const desc=document.createElement("p");desc.textContent=obj.description;
  card.append(title,desc);feed.append(card);
}
const menu=document.querySelector("#layerMenu");
document.querySelector("#layersBtn").addEventListener("click",()=>menu.classList.toggle("hidden"));
menu.addEventListener("change",e=>{
  const key=e.target.dataset.layer;if(!key)return;
  const map={districts:"#districtLayer",businesses:".map-object.business",billboards:".map-object.billboard",events:".map-object.event"};
  document.querySelectorAll(map[key]).forEach(n=>n.style.display=e.target.checked?"":"none");
});
if("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js"));
